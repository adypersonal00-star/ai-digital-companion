# AI Digital Companion

Android starter project for the offline-first AI companion requested by Ady.

Current build scope: accessible dark chat shell, local conversation persistence, temporary chat creation, chat options (rename/copy/export/delete), file picker entry point, model catalog screen, and settings navigation.

Important: model execution, model downloads, AI replies, generated audio/images, transcription, TTS, camera/screen streaming, and background voice session are not yet integrated. The model screen is informational and does not pretend these engines work.

Build with JDK 17 and Gradle 8.9: `gradle assembleDebug`.
