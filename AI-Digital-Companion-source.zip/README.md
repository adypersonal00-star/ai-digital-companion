# AI Digital Companion

Android starter project for the offline-first AI companion requested by Ady.

Current build scope: accessible dark chat shell, local conversation persistence, temporary chat creation, chat options (rename/copy/export/delete), file picker entry point, model catalog screen, and settings navigation.

Important: The model catalog now downloads pinned model files into internal app storage, reports progress, verifies expected byte length and SHA-256, and removes incomplete/corrupt downloads. These are weights only. Llama.cpp, whisper.cpp, Sherpa-ONNX, LiteRT SoundGen, and stable-diffusion.cpp inference runtimes are not yet integrated; AI replies, speech transcription/TTS, generated audio/images, camera/screen streaming, and background voice are not yet operational. Never describe these as installed engines.

Build with JDK 17 and Gradle 8.9: `gradle assembleDebug`.
