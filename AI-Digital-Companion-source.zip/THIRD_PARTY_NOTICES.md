# Third-party notices

## LLaMA Kotlin Android

The chat runtime uses `org.codeshipping:llama-kotlin-android:0.1.0`, published under the MIT License. It includes Android JNI native libraries built from llama.cpp. Upstream source and full license: https://github.com/CodeShipping/llama-kotlin-android (MIT). Maven Central AAR SHA-256: `63926e4a250e565e02015ed0ff3be77e826fd6b32a7207a35a648b0bce775fb5`.
