package ai.ady.companion

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.codeshipping.llamakotlin.LlamaConfig
import org.codeshipping.llamakotlin.LlamaModel
import java.io.File

/** Real on-device GGUF inference; all native model work is serialized off the UI thread. */
object LocalChatEngine {
    interface Callback {
        fun onStatus(message: String)
        fun onResult(text: String)
        fun onError(message: String)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mutex = Mutex()
    private var model: LlamaModel? = null
    private var modelPath: String? = null

    @JvmStatic
    fun generate(path: String, chatMlPrompt: String, callback: Callback) {
        scope.launch {
            try {
                val answer = mutex.withLock {
                    val f = File(path)
                    require(f.isFile && f.canRead()) { "Primero descarga el modelo Qwen2.5-0.5B en Ajustes → Modelos (468 MiB)." }
                    if (model == null || modelPath != f.absolutePath || model?.isLoaded != true) {
                        callback.onStatus("Cargando Qwen2.5 en este dispositivo… La primera carga puede tardar.")
                        model?.close()
                        model = null
                        modelPath = null
                        // Small bounded context and CPU thread count suit lower-memory phones.
                        model = LlamaModel.load(f.absolutePath, LlamaConfig().apply {
                            contextSize = 1024
                            batchSize = 128
                            threads = 2
                            threadsBatch = 2
                            maxTokens = 256
                            temperature = 0.7f
                            topP = 0.9f
                            topK = 40
                            repeatPenalty = 1.1f
                            useMmap = true
                            useMlock = false
                            gpuLayers = 0
                        })
                        modelPath = f.absolutePath
                    }
                    callback.onStatus("Generando respuesta local…")
                    model!!.generate(chatMlPrompt).trim()
                        .substringBefore("<|im_end|>").substringBefore("<|endoftext|>").trim()
                }
                if (answer.isBlank()) callback.onError("El modelo no generó texto. Prueba con un mensaje más corto.")
                else callback.onResult(answer)
            } catch (e: OutOfMemoryError) {
                mutex.withLock { model?.close(); model = null; modelPath = null }
                callback.onError("No hay memoria suficiente para cargar o ejecutar el modelo. Cierra otras apps y vuelve a intentarlo.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                val msg = e.message ?: e.javaClass.simpleName
                callback.onError(if (msg.contains("memory", true) || msg.contains("alloc", true))
                    "El teléfono no tiene memoria disponible suficiente para esta respuesta. Cierra otras apps y vuelve a intentarlo."
                else "No se pudo ejecutar el modelo local: $msg")
            }
        }
    }

    /** Release native allocations when Android reports severe memory pressure. */
    @JvmStatic
    fun releaseWhenIdle() {
        scope.launch {
            mutex.withLock {
                model?.close()
                model = null
                modelPath = null
            }
        }
    }
}
