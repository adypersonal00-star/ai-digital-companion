package ai.ady.companion

import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.runBlocking
import org.codeshipping.llamakotlin.LlamaModel
import java.util.concurrent.Executors

/** Ejecuta generación GGUF local mediante llama.cpp, fuera del hilo de interfaz. */
object LocalChatRunner {
    interface Callback {
        fun onResult(answer: String?, error: String?)
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @JvmStatic
    fun generate(modelPath: String, prompt: String, callback: Callback) {
        worker.execute {
            try {
                val answer = runBlocking {
                    val model = LlamaModel.load(modelPath) {
                        contextSize = 1024
                        batchSize = 128
                        threads = 2
                        threadsBatch = 2
                        temperature = 0.7f
                        topP = 0.9f
                        maxTokens = 192
                        gpuLayers = 0
                        useMmap = true
                    }
                    try { model.generate(prompt).trim() } finally { model.close() }
                }
                if (answer.isBlank()) throw IllegalStateException("El modelo no produjo texto.")
                main.post { callback.onResult(answer, null) }
            } catch (t: Throwable) {
                val message = t.message ?: "No se pudo ejecutar el modelo local."
                main.post { callback.onResult(null, message) }
            }
        }
    }
}
