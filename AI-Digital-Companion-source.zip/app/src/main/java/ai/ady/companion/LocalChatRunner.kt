package ai.ady.companion

import android.os.Handler
import android.os.Looper
import org.codeshipping.llamakotlin.LlamaModel
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors

/** Ejecuta el modelo GGUF local con llama.cpp y libera sus recursos al terminar. */
object LocalChatRunner {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun generate(modelPath: String, prompt: String, callback: (String?, String?) -> Unit) {
        worker.execute {
            try {
                val response = runBlocking {
                    val model = LlamaModel.load(modelPath) {
                        contextSize = 1024
                        batchSize = 128
                        threads = 2
                        threadsBatch = 2
                        temperature = 0.7f
                        topP = 0.9f
                        maxTokens = 192
                        gpuLayers = 0
                        useMmap = true
                    }
                    try { model.generate(prompt).trim() } finally { model.close() }
                }
                if (response.isEmpty()) throw IllegalStateException("El modelo no produjo texto.")
                main.post { callback(response, null) }
            } catch (t: Throwable) {
                val message = t.message ?: "No se pudo ejecutar el modelo local."
                main.post { callback(null, message) }
            }
        }
    }
}
