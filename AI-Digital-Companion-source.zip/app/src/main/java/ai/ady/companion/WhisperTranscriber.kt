package ai.ady.companion

import com.whispercpp.whisper.WhisperContext
import kotlinx.coroutines.runBlocking

/** JNI whisper.cpp, con el idioma fijado a español en el puente nativo. */
object WhisperTranscriber {
    @JvmStatic
    fun transcribe(modelPath: String, samples: FloatArray): String = runBlocking {
        val context = WhisperContext.createContextFromFile(modelPath)
        try { context.transcribeData(samples, false).trim() }
        finally { context.release() }
    }
}
