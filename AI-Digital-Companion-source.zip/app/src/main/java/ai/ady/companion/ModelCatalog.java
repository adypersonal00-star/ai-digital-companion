package ai.ady.companion;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Download-only catalog. A downloaded checkpoint is not considered an executable engine. */
public final class ModelCatalog {
    public interface Listener { void onProgress(long done,long total); void onComplete(File file); void onError(String message); }
    public static final class Item {
        public final String id,title,description,url,filename,sha256;
        public final long size;
        Item(String i,String t,String d,String u,String f,long s,String h){id=i;title=t;description=d;url=u;filename=f;size=s;sha256=h;}
    }
    public static final Item[] ITEMS={
        new Item("soundgen","SoundGen · tokenizador", "Parte 1/5 · 9,7 MiB", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/audiogen?download=true","soundgen-audiogen",10179872,"a32ee43e795a3c0615f0c805ad1dfcbff589e43809a77569f265ec623d840b4c"),
        new Item("soundgen_ae","SoundGen · decodificador", "Parte 2/5 · 298 MiB", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/autoencoder_model.tflite?download=true","soundgen-autoencoder.tflite",312588244,"e5483ee50915af1ac419fce5206f14b55572176fcb9cf327ef48432d4c5feba2"),
        new Item("soundgen_cond","SoundGen · condicionador", "Parte 3/5 · 420 MiB", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/conditioners_float32.tflite?download=true","soundgen-conditioners.tflite",440190572,"c1139b09ea66a944966dfce4722075401f9eb723c1f59bfd5bdd797690bcce91"),
        new Item("soundgen_dit","SoundGen · modelo DiT", "Parte 4/5 · 328 MiB", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/dit_model.tflite?download=true","soundgen-dit.tflite",344293232,"119fe0020f2fafd88366a2869fdbf2f1aaa3933f8daf64d2116dcc115348ee83"),
        new Item("soundgen_spiece","SoundGen · tokenizer", "Parte 5/5 · 773 KiB", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/spiece.model?download=true","soundgen-spiece.model",791656,"d60acb128cf7b7f2536e8f38a5b18a05535c9e14c7a355904270e15b0945ea86"),
        new Item("whisper","Whisper Tiny multilingüe","STT para Android · 30.7 MiB Q5_1", "https://huggingface.co/ggerganov/whisper.cpp/resolve/5359861c739e955e79d9a303bcbc70fb988958b1/ggml-tiny-q5_1.bin?download=true","whisper-tiny-q5_1.bin",32152673,"818710568da3ca15689e31a743197b520007872ff9576237bda97bd1b469c3d7"),
        new Item("piper","Piper español México","Modelo ONNX · 60.2 MiB", "https://huggingface.co/rhasspy/piper-voices/resolve/e7229f7d33a10e145e109b886d661984201ac3c4/es/es_MX/claude/high/es_MX-claude-high.onnx?download=true","piper-es-MX-claude.onnx",63122309,"3ef40a71ea63852cd8ab7e6fa7d2ecdcfa67a0b47c9c48e3f10e02ee02083ea0"),
        new Item("piper_json","Piper español México · config","Configuración de fonemas y voz · 4.8 KiB", "https://huggingface.co/rhasspy/piper-voices/resolve/e7229f7d33a10e145e109b886d661984201ac3c4/es/es_MX/claude/high/es_MX-claude-high.onnx.json?download=true","piper-es-MX-claude.onnx.json",4963,""),
        new Item("sd15","Stable Diffusion 1.5 Q4","Checkpoint GGUF · 1.63 GiB. Requiere stable-diffusion.cpp Android aún no integrado.","https://huggingface.co/gpustack/stable-diffusion-v1-5-GGUF/resolve/dcac270609fffc0ce7c7d41a3c0e752721859f7c/stable-diffusion-v1-5-Q4_0.gguf?download=true","sd15-q4_0.gguf",1747190784,"c2f6e92f9d08d69cc673a1003528ac8199274b3c0eaec88d5fbefe5af67bd42b"),
        new Item("qwen05","Qwen2.5 0.5B Instruct Q4_K_M","Chat GGUF · 468 MiB. Inference local con llama.cpp; primera respuesta requiere descargar el modelo.","https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/df5bf01389a39c743ab467d734bf501681e041c5/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true","qwen2.5-0.5b-instruct-q4_k_m.gguf",491400032,"74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db")
    };
    private final Context app; private final ExecutorService io=Executors.newSingleThreadExecutor(); private final Handler ui=new Handler(Looper.getMainLooper());
    public ModelCatalog(Context c){app=c.getApplicationContext();}
    public File file(Item x){return new File(new File(app.getFilesDir(),"models"),x.filename);}
    public boolean installed(Item x){File f=file(x);return f.exists()&&f.length()==x.size;}
    public void download(Item x,Listener l){io.execute(()->{File dest=file(x),part=new File(dest.getParentFile(),dest.getName()+".part");try{if(!dest.getParentFile().exists()&&!dest.getParentFile().mkdirs())throw new IOException("No se pudo crear la carpeta de modelos");HttpURLConnection c=(HttpURLConnection)new URL(x.url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setRequestProperty("User-Agent","AI-Digital-Companion/0.1");int code=c.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);long total=c.getContentLengthLong()>0?c.getContentLengthLong():x.size;MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){byte[] b=new byte[65536];long n=0;int k;while((k=in.read(b))!=-1){out.write(b,0,k);md.update(b,0,k);n+=k;long dn=n;ui.post(()->l.onProgress(dn,total));}}finally{c.disconnect();}if(x.size>0&&part.length()!=x.size)throw new IOException("Tamaño incorrecto: "+part.length()+" de "+x.size+" bytes");String hash=hex(md.digest());if(!x.sha256.isEmpty()&&!x.sha256.equalsIgnoreCase(hash))throw new IOException("SHA-256 no coincide; se descartó la descarga");if(dest.exists())dest.delete();if(!part.renameTo(dest))throw new IOException("No se pudo finalizar el archivo");ui.post(()->l.onComplete(dest));}catch(Exception e){part.delete();String m=e.getMessage()==null?"Error de descarga":e.getMessage();ui.post(()->l.onError(m));}});}
    private static String hex(byte[] a){StringBuilder s=new StringBuilder();for(byte b:a)s.append(String.format(java.util.Locale.US,"%02x",b&255));return s.toString();}
}
