package ai.ady.companion;

import android.graphics.Bitmap;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class ImageGeneratorNative {
 static { System.loadLibrary("whisper"); }
 private ImageGeneratorNative() {}
 public static native byte[] generate(String modelPath,String prompt,int width,int height,int steps,long seed);
 public static Bitmap generateBitmap(String path,String prompt,int w,int h,int steps,long seed){byte[] b=generate(path,prompt,w,h,steps,seed);if(b==null||b.length<8)throw new IllegalStateException("El motor Stable Diffusion no pudo generar la imagen.");ByteBuffer bb=ByteBuffer.wrap(b).order(ByteOrder.nativeOrder());int width=bb.getInt(),height=bb.getInt();if(width<1||height<1||b.length<8+width*height*3)throw new IllegalStateException("La imagen generada está incompleta.");int[] px=new int[width*height];for(int i=0;i<px.length;i++){int r=b[8+i*3]&255,g=b[9+i*3]&255,bl=b[10+i*3]&255;px[i]=0xff000000|(r<<16)|(g<<8)|bl;}Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);out.setPixels(px,0,width,0,0,width,height);return out;}
}
