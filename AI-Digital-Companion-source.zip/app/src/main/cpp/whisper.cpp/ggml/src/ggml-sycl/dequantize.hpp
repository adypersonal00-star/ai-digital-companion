//
// MIT license
// Copyright (C) 2024 Intel Corporation
// SPDX-License-Identifier: MIT
//

//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//

#ifndef GGML_SYCL_DEQUANTIZE_HPP
#define GGML_SYCL_DEQUANTIZE_HPP

#include "common.hpp"
#include "convert.hpp"

typedef void (*dequantize_kernel_t)(const void * vx, const int64_t ib, const int iqs, dfloat2 & v);
typedef void (*dequantize_kernel_t_reorder)(const void *d, const int64_t ib, const void *qs,
                                            const int iqs, dfloat2 &v);
typedef void (*dequantize_kernel_f32_t)(const void * vx, const int64_t ib, const int iqs, float & v0, float & v1);

#if QK_K == 256
static inline void get_scale_min_k4(int j, const uint8_t * q, uint8_t & d, uint8_t & m);
#endif

static __dpct_inline__ void dequantize_q2_0(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q2_0 * x = (const block_q2_0 *) vx;

    const dfloat d = x[ib].d;

    const int byte_idx = iqs / 4;
    const int shift = (iqs % 4) * 2;
    const uint8_t vui = x[ib].qs[byte_idx];

    v.x() = (vui >> shift) & 3;
    v.y() = (vui >> (shift + 2)) & 3;

#ifdef GGML_SYCL_F16
    v.s0() = ((dfloat)v.s0() - 1.0f) * d;
    v.s1() = ((dfloat)v.s1() - 1.0f) * d;
#else
    v.x() = ((dfloat)v.x() - 1.0f) * d;
    v.y() = ((dfloat)v.y() - 1.0f) * d;
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q4_0(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q4_0 * x = (const block_q4_0 *) vx;

    const dfloat d = x[ib].d;

    const int vui = x[ib].qs[iqs];

    v.x() = vui & 0xF;
    v.y() = vui >> 4;

#ifdef GGML_SYCL_F16
    // v = v - {8.0f, 8.0f};
    // v = v * {d, d};
    v.s0() = (v.s0() - 8.0f) * d;
    v.s1() = (v.s1() - 8.0f) * d;

#else
    v.x() = (v.x() - 8.0f) * d;
    v.y() = (v.y() - 8.0f) * d;
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q4_0_reorder(const void *d_ptr, const int64_t ib, const void *qs,
                                            const int iqs, dfloat2 &v) {
    // const block_q4_0 * x = (const block_q4_0 *) vx;

    const dfloat d = (const dfloat)*((const sycl::half*)d_ptr+ib);

    const int vui = *((const uint8_t *)qs+iqs);

    v.x() = vui & 0xF;
    v.y() = vui >> 4;

#ifdef GGML_SYCL_F16
    // v = v - {8.0f, 8.0f};
    // v = v * {d, d};
    v.s0() = (v.s0() - 8.0f) * d;
    v.s1() = (v.s1() - 8.0f) * d;

#else
    v.x() = (v.x() - 8.0f) * d;
    v.y() = (v.y() - 8.0f) * d;
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q1_0_reorder(const void *d_ptr, const int64_t ib, const void *qs,
                                            const int iqs, dfloat2 &v) {
    // Q1_0 reorder layout: scale values followed by quantized bits
    const dfloat d = (const dfloat)*((const sycl::half*)d_ptr+ib);

    const int bit_index_0 = iqs + 0;
    const int bit_index_1 = iqs + 1;

    const int bit_0 = (*((const uint8_t *)qs + bit_index_0 / 8) >> (bit_index_0 % 8)) & 1;
    const int bit_1 = (*((const uint8_t *)qs + bit_index_1 / 8) >> (bit_index_1 % 8)) & 1;

    v.x() = (2 * bit_0 - 1) * d;
    v.y() = (2 * bit_1 - 1) * d;
}

static __dpct_inline__ void dequantize_q1_0(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q1_0 * x = (const block_q1_0 *) vx;
    const dfloat d = x[ib].d;

    const int bit_index_0 = iqs + 0;
    const int bit_index_1 = iqs + 1;

    const int bit_0 = (x[ib].qs[bit_index_0 / 8] >> (bit_index_0 % 8)) & 1;
    const int bit_1 = (x[ib].qs[bit_index_1 / 8] >> (bit_index_1 % 8)) & 1;

    v.x() = (2 * bit_0 - 1) * d;
    v.y() = (2 * bit_1 - 1) * d;
}

static __dpct_inline__ void dequantize_q4_1(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q4_1 * x = (const block_q4_1 *) vx;

    const dfloat d = x[ib].dm[0];
    const dfloat m = x[ib].dm[1];

    const int vui = x[ib].qs[iqs];

    v.x() = vui & 0xF;
    v.y() = vui >> 4;

#ifdef GGML_SYCL_F16
    // v = v * {d, d};
    // v = v + {m, m};
    v.s0() = sycl::fma(v.s0(), d, m);
    v.s1() = sycl::fma(v.s1(), d, m);

#else
    v.x() = sycl::fma(v.x(), d, m);
    v.y() = sycl::fma(v.y(), d, m);
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q4_K(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_q4_K * x = (const block_q4_K *) vx;
    const sycl::half2 dm = x[ib].dm;
    const float dall = dm[0];
    const float dmin = dm[1];

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int il = idx / 64;
        const int in = idx % 64;
        const int is = 2 * il + (in >= 32 ? 1 : 0);
        const int off = in & 31;
        const int qsi = 32 * il + off;

        uint8_t sc;
        uint8_t m;
        get_scale_min_k4(is, x[ib].scales, sc, m);

        const uint8_t q = x[ib].qs[qsi];
        const uint8_t qv = (in >= 32) ? (q >> 4) : (q & 0xF);
        return sycl::fma((dfloat) qv, (dfloat) (dall * sc), (dfloat) (-dmin * m));
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q4_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q4_K_f32(const void *vx, const int64_t ib,
                                                const int iqs, float &v0, float &v1) {
#if QK_K == 256
    const block_q4_K * x = (const block_q4_K *) vx;
    const sycl::half2 dm = x[ib].dm;
    const float dall = dm[0];
    const float dmin = dm[1];

    auto dequantize_one = [&](const int idx) -> float {
        const int il = idx / 64;
        const int in = idx % 64;
        const int is = 2 * il + (in >= 32 ? 1 : 0);
        const int qsi = 32 * il + (in & 31);

        uint8_t sc;
        uint8_t m;
        get_scale_min_k4(is, x[ib].scales, sc, m);

        const float d = dall * sc;
        const float mn = dmin * m;
        const uint8_t q = x[ib].qs[qsi];
        const uint8_t qv = (in >= 32) ? (q >> 4) : (q & 0xF);

        return d * qv - mn;
    };

    v0 = dequantize_one(iqs + 0);
    v1 = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q4_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q2_K(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_q2_K * x = (const block_q2_K *) vx;
    const float dall = x[ib].dm[0];
    const float dmin = x[ib].dm[1];

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int n = idx / 128;
        const int r = idx % 128;
        const int g = r / 32;
        const int l = r % 32;
        const int is = 8 * n + l / 16;

        const uint8_t q = x[ib].qs[32 * n + l];
        const uint8_t sc = x[ib].scales[is + 2 * g];
        const float d = dall * (sc & 0xF);
        const float m = dmin * (sc >> 4);

        return (dfloat) d * (dfloat) ((q >> (2 * g)) & 3) - (dfloat) m;
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q2_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q2_K_f32(const void *vx, const int64_t ib,
                                                const int iqs, float &v0, float &v1) {
#if QK_K == 256
    const block_q2_K * x = (const block_q2_K *) vx;
    const float dall = x[ib].dm[0];
    const float dmin = x[ib].dm[1];

    auto dequantize_one = [&](const int idx) -> float {
        const int n = idx / 128;
        const int r = idx % 128;
        const int g = r / 32;
        const int l = r % 32;
        const int is = 8 * n + l / 16;

        const uint8_t q = x[ib].qs[32 * n + l];
        const uint8_t sc = x[ib].scales[is + 2 * g];
        const float d = dall * (sc & 0xF);
        const float m = dmin * (sc >> 4);

        return d * ((q >> (2 * g)) & 3) - m;
    };

    v0 = dequantize_one(iqs + 0);
    v1 = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q2_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q3_K(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_q3_K * x = (const block_q3_K *) vx;
    const float d_all = x[ib].d;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int n = idx / 128;
        const int r = idx % 128;
        const int j = r / 32;
        const int l = r % 32;

        const int is0 = l / 16;
        const int is = 8 * n + 2 * j + is0;
        const int shift = 2 * j;
        const uint8_t m = 1 << (4 * n + j);

        const int8_t us = is <  4 ? (x[ib].scales[is - 0] & 0xF) | (((x[ib].scales[is + 8] >> 0) & 3) << 4) :
                         is <  8 ? (x[ib].scales[is - 0] & 0xF) | (((x[ib].scales[is + 4] >> 2) & 3) << 4) :
                         is < 12 ? (x[ib].scales[is - 8] >> 4)  | (((x[ib].scales[is + 0] >> 4) & 3) << 4) :
                                   (x[ib].scales[is - 8] >> 4)  | (((x[ib].scales[is - 4] >> 6) & 3) << 4);

        const float dl = d_all * (us - 32);
        const uint8_t q = x[ib].qs[32 * n + l];
        const uint8_t h = x[ib].hmask[l];
        const int8_t qv = ((q >> shift) & 3) - ((h & m) ? 0 : 4);

        return (dfloat) (dl * qv);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q3_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q5_K(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_q5_K * x = (const block_q5_K *) vx;
    const float dall = x[ib].dm[0];
    const float dmin = x[ib].dm[1];

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int il = idx / 64;
        const int in = idx % 64;
        const int is = 2 * il + (in >= 32 ? 1 : 0);
        const int ir = (in & 31) / 2;
        const int iq = in & 1;

        const uint8_t q = x[ib].qs[32 * il + 2 * ir + iq];
        const uint8_t h = x[ib].qh[2 * ir + iq];
        const uint8_t qv = (in >= 32) ? (q >> 4) : (q & 0xF);

        uint8_t sc;
        uint8_t m;
        get_scale_min_k4(is, x[ib].scales, sc, m);

        const float d = dall * sc;
        const float mn = dmin * m;
        const uint8_t hm = 1 << (2 * il + (in >= 32 ? 1 : 0));

        return sycl::fma((dfloat) (qv + ((h & hm) ? 16 : 0)), (dfloat) d, (dfloat) (-mn));
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q5_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q5_K_f32(const void *vx, const int64_t ib,
                                                const int iqs, float &v0, float &v1) {
#if QK_K == 256
    const block_q5_K * x = (const block_q5_K *) vx;
    const float dall = x[ib].dm[0];
    const float dmin = x[ib].dm[1];

    auto dequantize_one = [&](const int idx) -> float {
        const int il = idx / 64;
        const int in = idx % 64;
        const int is = 2 * il + (in >= 32 ? 1 : 0);
        const int ir = (in & 31) / 2;
        const int iq = in & 1;

        const uint8_t q = x[ib].qs[32 * il + 2 * ir + iq];
        const uint8_t h = x[ib].qh[2 * ir + iq];
        const uint8_t qv = (in >= 32) ? (q >> 4) : (q & 0xF);

        uint8_t sc;
        uint8_t m;
        get_scale_min_k4(is, x[ib].scales, sc, m);

        const float d = dall * sc;
        const float mn = dmin * m;
        const uint8_t hm = 1 << (2 * il + (in >= 32 ? 1 : 0));

        return (qv + ((h & hm) ? 16 : 0)) * d - mn;
    };

    v0 = dequantize_one(iqs + 0);
    v1 = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q5_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q6_K(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_q6_K * x = (const block_q6_K *) vx;
    const float d = x[ib].d;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ip = idx / 128;
        const int in = idx % 128;
        const int il = in & 31;
        const int ig = in / 32;
        const int is = 8 * ip + il / 16;

        const uint8_t ql0 = x[ib].ql[64 * ip + il];
        const uint8_t ql1 = x[ib].ql[64 * ip + il + 32];
        const uint8_t qh = x[ib].qh[32 * ip + il];
        const int8_t * sc = x[ib].scales + is;

        uint8_t qv;
        int8_t scale;
        if (ig == 0) {
            qv = (ql0 & 0xF) | (((qh >> 0) & 3) << 4);
            scale = sc[0];
        } else if (ig == 1) {
            qv = (ql1 & 0xF) | (((qh >> 2) & 3) << 4);
            scale = sc[2];
        } else if (ig == 2) {
            qv = (ql0 >> 4) | (((qh >> 4) & 3) << 4);
            scale = sc[4];
        } else {
            qv = (ql1 >> 4) | (((qh >> 6) & 3) << 4);
            scale = sc[6];
        }

        return (dfloat) (d * scale * ((int8_t) qv - 32));
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("Q6_K dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_mxfp4(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
    const block_mxfp4 * x = (const block_mxfp4 *) vx;
    const float d = ggml_sycl_e8m0_to_fp32(x[ib].e);
    const uint8_t q = x[ib].qs[iqs];

    v.x() = d * kvalues_mxfp4[q & 0xF] * 0.5f;
    v.y() = d * kvalues_mxfp4[q >> 4] * 0.5f;
}

static __dpct_inline__ void dequantize_nvfp4(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
    const block_nvfp4 & xb = ((const block_nvfp4 *) vx)[ib];

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int sub = idx / QK_NVFP4_SUB;
        const int j = idx % QK_NVFP4_SUB;
        const int jh = j % (QK_NVFP4_SUB / 2);

        const float d = ggml_sycl_ue4m3_to_fp32(xb.d[sub]);
        const uint8_t q = xb.qs[sub * (QK_NVFP4_SUB / 2) + jh];
        const uint8_t qv = (j < (QK_NVFP4_SUB / 2)) ? (q & 0x0F) : (q >> 4);

        return d * kvalues_mxfp4[qv];
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
}

static __dpct_inline__ void dequantize_iq2_xxs(const void *vx, const int64_t ib,
                                               const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq2_xxs * x = (const block_iq2_xxs *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint16_t * q2 = x[ib].qs + 4 * ib8;
        const uint8_t * aux8 = (const uint8_t *) q2;
        const uint8_t * grid = (const uint8_t *) (iq2xxs_grid + aux8[il]);
        const uint32_t aux32 = q2[2] | (q2[3] << 16);
        const float d = (float) x[ib].d * (0.5f + (aux32 >> 28)) * 0.25f;
        const uint8_t signs = ksigns_iq2xs[(aux32 >> (7 * il)) & 127];

        return d * grid[j] * ((signs & kmask_iq2xs[j]) ? -1.f : 1.f);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ2_XXS dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq2_xs(const void *vx, const int64_t ib,
                                              const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq2_xs * x = (const block_iq2_xs *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint16_t * q2 = x[ib].qs + 4 * ib8;
        const uint8_t * grid = (const uint8_t *) (iq2xs_grid + (q2[il] & 511));
        const float d = (float) x[ib].d * (0.5f + ((x[ib].scales[ib8] >> (4 * (il / 2))) & 0xf)) * 0.25f;
        const uint8_t signs = ksigns_iq2xs[q2[il] >> 9];

        return d * grid[j] * ((signs & kmask_iq2xs[j]) ? -1.f : 1.f);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ2_XS dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq2_s(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq2_s * x = (const block_iq2_s *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint16_t grid_id = x[ib].qs[4 * ib8 + il] | ((x[ib].qh[ib8] << (8 - 2 * il)) & 0x300);
        const uint8_t * grid = (const uint8_t *) (iq2s_grid + grid_id);
        const float d = (float) x[ib].d * (0.5f + ((x[ib].scales[ib8] >> (4 * (il / 2))) & 0xf)) * 0.25f;
        const uint8_t signs = x[ib].qs[QK_K / 8 + 4 * ib8 + il];

        return d * grid[j] * ((signs & kmask_iq2xs[j]) ? -1.f : 1.f);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ2_S dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq3_xxs(const void *vx, const int64_t ib,
                                               const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq3_xxs * x = (const block_iq3_xxs *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint8_t * q3 = x[ib].qs + 8 * ib8;
        const uint16_t * gas = (const uint16_t *) (x[ib].qs + QK_K / 4) + 2 * ib8;
        const uint8_t * grid1 = (const uint8_t *) (iq3xxs_grid + q3[2 * il + 0]);
        const uint8_t * grid2 = (const uint8_t *) (iq3xxs_grid + q3[2 * il + 1]);
        const uint32_t aux32 = gas[0] | (gas[1] << 16);
        const float d = (float) x[ib].d * (0.5f + (aux32 >> 28)) * 0.5f;
        const uint8_t signs = ksigns_iq2xs[(aux32 >> (7 * il)) & 127];

        if (j < 4) {
            return d * grid1[j] * ((signs & kmask_iq2xs[j + 0]) ? -1.f : 1.f);
        }
        return d * grid2[j - 4] * ((signs & kmask_iq2xs[j + 0]) ? -1.f : 1.f);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ3_XXS dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq3_s(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq3_s * x = (const block_iq3_s *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint8_t * qs = x[ib].qs + 8 * ib8;
        const uint16_t grid1_id = qs[2 * il + 0] | ((x[ib].qh[ib8] << (8 - 2 * il)) & 256);
        const uint16_t grid2_id = qs[2 * il + 1] | ((x[ib].qh[ib8] << (7 - 2 * il)) & 256);
        const uint8_t * grid1 = (const uint8_t *) (iq3s_grid + grid1_id);
        const uint8_t * grid2 = (const uint8_t *) (iq3s_grid + grid2_id);
        const float d = (float) x[ib].d * (1 + 2 * ((x[ib].scales[ib8 / 2] >> (4 * (ib8 % 2))) & 0xf));
        const uint8_t signs = x[ib].signs[4 * ib8 + il];

        if (j < 4) {
            return d * grid1[j] * ((signs & kmask_iq2xs[j + 0]) ? -1.f : 1.f);
        }
        return d * grid2[j - 4] * ((signs & kmask_iq2xs[j + 0]) ? -1.f : 1.f);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ3_S dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq1_s(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq1_s * x = (const block_iq1_s *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const float delta = (x[ib].qh[ib8] & 0x8000) ? (-1.f - IQ1S_DELTA) : (-1.f + IQ1S_DELTA);
        const float d = (float) x[ib].d * (2 * ((x[ib].qh[ib8] >> 12) & 7) + 1);
        const uint16_t grid_id = x[ib].qs[4 * ib8 + il] | (((x[ib].qh[ib8] >> (3 * il)) & 7) << 8);
        const uint32_t g = iq1s_grid_gpu[grid_id];
        const int8_t qv = (j < 4) ? ((g >> (8 * j)) & 0x0F) : ((g >> (8 * (j - 4) + 4)) & 0x0F);

        return d * (qv + delta);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ1_S dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq1_m(const void *vx, const int64_t ib,
                                             const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq1_m * x = (const block_iq1_m *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int il = r / 8;
        const int j = r % 8;

        const uint16_t * sc = (const uint16_t *) x[ib].scales;
        iq1m_scale_t scale;
        scale.u16 = (sc[0] >> 12) | ((sc[1] >> 8) & 0x00f0) | ((sc[2] >> 4) & 0x0f00) | (sc[3] & 0xf000);

        const int ib16 = 2 * ib8 + il / 2;
        const float d = (float) scale.f16 * (2 * ((sc[ib16 / 4] >> (3 * (ib16 % 4))) & 0x7) + 1);

        const uint8_t qh = x[ib].qh[2 * ib8 + il / 2];
        const float delta = (qh & (0x08 << (4 * (il % 2)))) ? (-1.f - IQ1M_DELTA) : (-1.f + IQ1M_DELTA);

        const uint16_t grid_id = x[ib].qs[4 * ib8 + il] | (((qh >> (4 * (il % 2))) & 7) << 8);
        const uint32_t g = iq1s_grid_gpu[grid_id];
        const int8_t qv = (j < 4) ? ((g >> (8 * j)) & 0x0F) : ((g >> (8 * (j - 4) + 4)) & 0x0F);

        return d * (qv + delta);
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ1_M dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_iq4_nl(const void *vx, const int64_t ib,
                                              const int iqs, dfloat2 &v) {
    const block_iq4_nl * x = (const block_iq4_nl *) vx;
    const float d = (float) x[ib].d;

    auto dequantize_one = [&](const int idx) -> dfloat {
        if (idx < 16) {
            return d * kvalues_iq4nl[x[ib].qs[idx] & 0xF];
        }
        return d * kvalues_iq4nl[x[ib].qs[idx - 16] >> 4];
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
}

static __dpct_inline__ void dequantize_iq4_xs(const void *vx, const int64_t ib,
                                              const int iqs, dfloat2 &v) {
#if QK_K == 256
    const block_iq4_xs * x = (const block_iq4_xs *) vx;

    auto dequantize_one = [&](const int idx) -> dfloat {
        const int ib8 = idx / 32;
        const int r = idx % 32;
        const int byte_idx = (r < 16) ? r : (r - 16);
        const uint8_t q = x[ib].qs[16 * ib8 + byte_idx];
        const uint8_t qv = (r < 16) ? (q & 0x0F) : (q >> 4);

        const float d = (float) x[ib].d * ((((x[ib].scales_l[ib8 / 2] >> (4 * (ib8 % 2))) & 0xf) |
                        (((x[ib].scales_h >> (2 * ib8)) & 3) << 4)) - 32);
        return d * kvalues_iq4nl[qv];
    };

    v.x() = dequantize_one(iqs + 0);
    v.y() = dequantize_one(iqs + 1);
#else
    GGML_ABORT("IQ4_XS dequantize not supported for QK_K != 256");
#endif
}

static __dpct_inline__ void dequantize_q5_0(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q5_0 * x = (const block_q5_0 *) vx;

    const dfloat d = x[ib].d;

    uint32_t qh;
    memcpy(&qh, x[ib].qh, sizeof(qh));

    const int xh_0 = ((qh >> (iqs +  0)) << 4) & 0x10;
    const int xh_1 = ((qh >> (iqs + 12))     ) & 0x10;

    v.x() = ((x[ib].qs[iqs] & 0xf) | xh_0);
    v.y() = ((x[ib].qs[iqs] >> 4) | xh_1);

#ifdef GGML_SYCL_F16
    // v = v - {16.0f, 16.0f};
    // v = v * {d, d};
    v.s0() = (v.s0() - 16.0f) * d;
    v.s1() = (v.s1() - 16.0f) * d;

#else
    v.x() = (v.x() - 16.0f) * d;
    v.y() = (v.y() - 16.0f) * d;
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q5_1(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q5_1 * x = (const block_q5_1 *) vx;

    const dfloat d = x[ib].dm[0];
    const dfloat m = x[ib].dm[1];

    uint32_t qh;
    memcpy(&qh, x[ib].qh, sizeof(qh));

    const int xh_0 = ((qh >> (iqs +  0)) << 4) & 0x10;
    const int xh_1 = ((qh >> (iqs + 12))     ) & 0x10;

    v.x() = ((x[ib].qs[iqs] & 0xf) | xh_0);
    v.y() = ((x[ib].qs[iqs] >> 4) | xh_1);

#ifdef GGML_SYCL_F16
    // v = v * {d, d};
    // v = v + {m, m};
    v.s0() = sycl::fma(v.s0(), d, m);
    v.s1() = sycl::fma(v.s1(), d, m);
#else
    v.x() = sycl::fma(v.x(), d, m);
    v.y() = sycl::fma(v.y(), d, m);
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q8_0_reorder(const void *d_ptr, const int64_t ib, const void *qs,
                                            const int iqs, dfloat2 &v) {
    const dfloat d = (const dfloat)*((const sycl::half*)d_ptr + ib);

    v.x() = ((const int8_t *)qs)[iqs + 0];
    v.y() = ((const int8_t *)qs)[iqs + 1];

#ifdef GGML_SYCL_F16
    v.s0() *= d;
    v.s1() *= d;
#else
    v.x() *= d;
    v.y() *= d;
#endif // GGML_SYCL_F16
}

static __dpct_inline__ void dequantize_q8_0(const void *vx, const int64_t ib,
                                            const int iqs, dfloat2 &v) {
    const block_q8_0 * x = (const block_q8_0 *) vx;

    const dfloat d = x[ib].d;

    v.x() = x[ib].qs[iqs + 0];
    v.y() = x[ib].qs[iqs + 1];

#ifdef GGML_SYCL_F16
    // v = v * {d, d};
    v.s0() *= d;
    v.s1() *= d;
#else
    v.x() *= d;
    v.y() *= d;
#endif // GGML_SYCL_F16
}

template<typename dst_t>
static void dequantize_block_q4_0(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t nb32,
                                  const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);

    // assume 32 threads
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t il  = tid/8;
    const int64_t ir  = tid%8;
    const int64_t ib = 8*i + ir;
    if (ib >= nb32) {
        return;
    }

    dst_t * y = yy + 256*i + 32*ir + 4*il;

    const block_q4_0 * x = (const block_q4_0 *)vx + ib;
    const float d = sycl::vec<sycl::half, 1>(x->d)
                        .convert<float, sycl::rounding_mode::automatic>()[0];
    const float dm = -8*d;

    const uint8_t * q = x->qs + 4*il;

    for (int l = 0; l < 4; ++l) {
        y[l+ 0] = d * (q[l] & 0xF) + dm;
        y[l+16] = d * (q[l] >>  4) + dm;
    }
}

// four qs bytes per item, all inside one 32-element block: two vec<dst_t,4> stores.
// float math, same products as the scalar kernel; nibble order kept (lo at +0, hi at +16).
template<typename dst_t>
static void dequantize_block_q4_0_reorder_wide(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t k,
                                               const sycl::id<1> idx) {
    const int64_t i   = (int64_t) idx[0];
    const int64_t ib  = i / 4;
    const int64_t iqs = 4 * (i % 4);

    const uint8_t *    qs    = (const uint8_t *) vx;
    const sycl::half * d_ptr = (const sycl::half *) ((const uint8_t *) vx + k/2);

    const float d = float(d_ptr[ib]);
    const uint8_t * q = qs + ib*(QK4_0/2) + iqs;

    sycl::vec<float, 4> lo, hi;
    lo[0] = d * ((q[0] & 0xF) - 8);
    lo[1] = d * ((q[1] & 0xF) - 8);
    lo[2] = d * ((q[2] & 0xF) - 8);
    lo[3] = d * ((q[3] & 0xF) - 8);
    hi[0] = d * ((q[0] >>  4) - 8);
    hi[1] = d * ((q[1] >>  4) - 8);
    hi[2] = d * ((q[2] >>  4) - 8);
    hi[3] = d * ((q[3] >>  4) - 8);

    dst_t * yb = yy + ib*QK4_0 + iqs;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb)           = lo.convert<dst_t, sycl::rounding_mode::automatic>();
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb + QK4_0/2) = hi.convert<dst_t, sycl::rounding_mode::automatic>();
}

// Dequantize Q8_0 from reorder layout: [all qs (k bytes)][all d values]
template<typename dst_t>
static void dequantize_block_q8_0_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t k,
                                  const sycl::nd_item<3> &item_ct1) {
    // two values per thread, like dequantize_block<dequantize_q8_0>; the reorder layout keeps all qs contiguous
    // grid-stride loop because the launcher may shrink the work-group to keep the global range below INT_MAX
    // float math, not dequantize_q8_0_reorder: that helper computes in half with GGML_SYCL_F16, which changes f32 output
    const int8_t *     qs     = (const int8_t *) vx;
    const sycl::half * d_ptr  = (const sycl::half *) ((const uint8_t *) vx + k);
    const int64_t      stride = 2 * item_ct1.get_local_range(2) * item_ct1.get_group_range(2);

    for (int64_t i = 2 * item_ct1.get_global_id(2); i < k; i += stride) {
        const float d = float(d_ptr[i / QK8_0]);

        yy[i + 0] = d * qs[i + 0];
        yy[i + 1] = d * qs[i + 1];
    }
}

template<typename dst_t>
static void dequantize_block_q8_0_reorder_wide(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t k,
                                               const sycl::id<1> idx) {
    const int64_t i = 4 * (int64_t) idx[0];

    const int8_t *     qs    = (const int8_t *) vx;
    const sycl::half * d_ptr = (const sycl::half *) ((const uint8_t *) vx + k);

    const float d0 = float(d_ptr[i / QK8_0]);
    const float d1 = float(d_ptr[(i + 2) / QK8_0]);

    sycl::vec<float, 4> p;
    p[0] = d0 * (float) qs[i + 0];
    p[1] = d0 * (float) qs[i + 1];
    p[2] = d1 * (float) qs[i + 2];
    p[3] = d1 * (float) qs[i + 3];

    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yy + i) = p.convert<dst_t, sycl::rounding_mode::automatic>();
}

template<typename dst_t>
static void dequantize_block_q4_1(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t nb32,
                                  const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);

    // assume 32 threads
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t il  = tid/8;
    const int64_t ir  = tid%8;
    const int64_t ib = 8*i + ir;
    if (ib >= nb32) {
        return;
    }

    dst_t * y = yy + 256*i + 32*ir + 4*il;

    const block_q4_1 * x = (const block_q4_1 *)vx + ib;
    const sycl::float2 d =
        x->dm.convert<float, sycl::rounding_mode::automatic>();

    const uint8_t * q = x->qs + 4*il;

    for (int l = 0; l < 4; ++l) {
        y[l + 0] = d.x() * (q[l] & 0xF) + d.y();
        y[l + 16] = d.x() * (q[l] >> 4) + d.y();
    }
}


//================================== k-quants

template<typename dst_t>
static void dequantize_block_q2_K(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                  const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);
    const block_q2_K * x = (const block_q2_K *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t n   = tid/32;
    const int64_t l   = tid - 32*n;
    const int64_t is  = 8*n + l/16;

    const uint8_t q = x[i].qs[32*n + l];
    dst_t * y = yy + i*QK_K + 128*n;

    float dall = x[i].dm[0];
    float dmin = x[i].dm[1];
    y[l+ 0] = dall * (x[i].scales[is+0] & 0xF) * ((q >> 0) & 3) - dmin * (x[i].scales[is+0] >> 4);
    y[l+32] = dall * (x[i].scales[is+2] & 0xF) * ((q >> 2) & 3) - dmin * (x[i].scales[is+2] >> 4);
    y[l+64] = dall * (x[i].scales[is+4] & 0xF) * ((q >> 4) & 3) - dmin * (x[i].scales[is+4] >> 4);
    y[l+96] = dall * (x[i].scales[is+6] & 0xF) * ((q >> 6) & 3) - dmin * (x[i].scales[is+6] >> 4);
#else
    const int64_t is = tid/16;  // 0 or 1
    const int64_t il = tid%16;  // 0...15
    const uint8_t q = x[i].qs[il] >> (2*is);
    dst_t * y = yy + i*QK_K + 16*is + il;

    float dall = x[i].dm[0];
    float dmin = x[i].dm[1];
    y[ 0] = dall * (x[i].scales[is+0] & 0xF) * ((q >> 0) & 3) - dmin * (x[i].scales[is+0] >> 4);
    y[32] = dall * (x[i].scales[is+2] & 0xF) * ((q >> 4) & 3) - dmin * (x[i].scales[is+2] >> 4);
#endif

}

template<typename dst_t>
static void dequantize_block_q2_K_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t i,
                                          const sycl::nd_item<3> & item_ct1, int64_t n_blocks) {
#if QK_K == 256
    if (i >= n_blocks) {
        return;
    }

    const uint8_t * base          = static_cast<const uint8_t *>(vx);
    const size_t    qs_offset     = i * (QK_K / 4);
    const size_t    scales_offset = n_blocks * (QK_K / 4) + i * (QK_K / 16);
    const size_t    dm_offset     = n_blocks * (QK_K / 4) + n_blocks * (QK_K / 16) + i * sizeof(ggml_half2);

    const uint8_t *     qs     = base + qs_offset;
    const uint8_t *     scales = base + scales_offset;
    const ggml_half2 * dm     = reinterpret_cast<const ggml_half2 *>(base + dm_offset);

    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t n   = tid / 32;             // 128-element chunk: 0 or 1
    const int64_t eh0 = 4 * (tid - 32 * n);   // base element within the chunk

    const int      shift = 2 * (eh0 / 32);    // 2-bit lane: 0/2/4/6
    const uint8_t * q4   = qs + 32 * n + (eh0 & 31);
    const uint8_t   sc0  = scales[8 * n + eh0 / 16];

    const float dall = (*dm)[0];
    const float dmin = (*dm)[1];

    // remapped decomposition: one aligned vec<dst_t,4> per thread instead of four
    // scalars strided 32 apart; a 4-run shares one scale byte and one 2-bit lane,
    // so the per-element math and output are identical to the scalar kernel.
    sycl::vec<dst_t, 4> v;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        v[j] = dall * (sc0 & 0xF) * ((q4[j] >> shift) & 3) - dmin * (sc0 >> 4);
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yy + 128 * n + eh0) = v;
#else
    GGML_UNUSED(vx);
    GGML_UNUSED(yy);
    GGML_UNUSED(i);
    GGML_UNUSED(item_ct1);
    GGML_UNUSED(n_blocks);
    GGML_ABORT("Q2_K reorder dequantize not supported for QK_K != 256");
#endif
}

template<typename dst_t>
static void dequantize_block_q3_K(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                  const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);
    const block_q3_K * x = (const block_q3_K *) vx;

#if QK_K == 256
    const int64_t r = item_ct1.get_local_id(2) / 4;
    const int64_t tid = r/2;
    const int64_t is0 = r%2;
    const int64_t l0 = 16 * is0 + 4 * (item_ct1.get_local_id(2) % 4);
    const int64_t n = tid / 4;
    const int64_t j = tid - 4*n;

    uint8_t m = 1 << (4*n + j);
    int64_t is = 8*n + 2*j + is0;
    int shift = 2*j;

    int8_t us = is <  4 ? (x[i].scales[is-0] & 0xF) | (((x[i].scales[is+8] >> 0) & 3) << 4) :
                is <  8 ? (x[i].scales[is-0] & 0xF) | (((x[i].scales[is+4] >> 2) & 3) << 4) :
                is < 12 ? (x[i].scales[is-8] >>  4) | (((x[i].scales[is+0] >> 4) & 3) << 4) :
                          (x[i].scales[is-8] >>  4) | (((x[i].scales[is-4] >> 6) & 3) << 4);
    float d_all = x[i].d;
    float dl = d_all * (us - 32);

    dst_t * y = yy + i*QK_K + 128*n + 32*j;
    const uint8_t * q = x[i].qs + 32*n;
    const uint8_t * hm = x[i].hmask;

    for (int l = l0; l < l0+4; ++l) y[l] = dl * ((int8_t)((q[l] >> shift) & 3) - ((hm[l] & m) ? 0 : 4));
#else
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t is  = tid/16;  // 0 or 1
    const int64_t il  = tid%16;  // 0...15
    const int64_t im  = il/8;    // 0...1
    const int64_t in  = il%8;    // 0...7

    dst_t * y = yy + i*QK_K + 16*is + il;

    const uint8_t q = x[i].qs[il] >> (2*is);
    const uint8_t h = x[i].hmask[in] >> (2*is + im);
    const float   d = (float)x[i].d;

    if (is == 0) {
        y[ 0] = d * ((x[i].scales[0] & 0xF) - 8) * ((int8_t)((q >> 0) & 3) - ((h >> 0) & 1 ? 0 : 4));
        y[32] = d * ((x[i].scales[1] & 0xF) - 8) * ((int8_t)((q >> 4) & 3) - ((h >> 4) & 1 ? 0 : 4));
    } else {
        y[ 0] = d * ((x[i].scales[0] >>  4) - 8) * ((int8_t)((q >> 0) & 3) - ((h >> 0) & 1 ? 0 : 4));
        y[32] = d * ((x[i].scales[1] >>  4) - 8) * ((int8_t)((q >> 4) & 3) - ((h >> 4) & 1 ? 0 : 4));
    }
#endif

}

template<typename dst_t>
static void dequantize_block_q3_K_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t i,
                                          const sycl::nd_item<3> & item_ct1, int64_t n_blocks) {
#if QK_K == 256
    if (i >= n_blocks) {
        return;
    }

    const uint8_t * base          = static_cast<const uint8_t *>(vx);
    const size_t    qs_offset     = i * (QK_K / 4);
    const size_t    hmask_offset  = n_blocks * (QK_K / 4) + i * (QK_K / 8);
    const size_t    scales_offset = n_blocks * (QK_K / 4) + n_blocks * (QK_K / 8) + i * 12;
    const size_t    d_offset      = n_blocks * (QK_K / 4) + n_blocks * (QK_K / 8) + n_blocks * 12 +
                                 i * sizeof(ggml_half);

    const uint8_t * qs     = base + qs_offset;
    const uint8_t * hmask  = base + hmask_offset;
    const uint8_t * scales = base + scales_offset;
    const float     d_all  = static_cast<float>(*reinterpret_cast<const ggml_half *>(base + d_offset));

    const int64_t r    = item_ct1.get_local_id(2) / 4;
    const int64_t tid  = r / 2;
    const int64_t is0  = r % 2;
    const int64_t l0   = 16 * is0 + 4 * (item_ct1.get_local_id(2) % 4);
    const int64_t n    = tid / 4;
    const int64_t j    = tid - 4 * n;
    const int64_t is   = 8 * n + 2 * j + is0;
    const int     shift = 2 * j;
    uint8_t       m    = 1 << (4 * n + j);

    uint8_t us = is < 4
        ? (scales[is - 0] & 0xF) | (((scales[is + 8] >> 0) & 3) << 4)
        : is < 8
            ? (scales[is - 0] & 0xF) | (((scales[is + 4] >> 2) & 3) << 4)
            : is < 12
                ? (scales[is - 8] >> 4) | (((scales[is + 0] >> 4) & 3) << 4)
                : (scales[is - 8] >> 4) | (((scales[is - 4] >> 6) & 3) << 4);

    const float dl = d_all * (us - 32);

    dst_t * y = yy + 128 * n + 32 * j;
    const uint8_t * q  = qs + 32 * n;
    const uint8_t * hm = hmask;

    sycl::vec<dst_t, 4> v;
#pragma unroll
    for (int jj = 0; jj < 4; ++jj) {
        v[jj] = dl * ((int8_t) ((q[l0 + jj] >> shift) & 3) - ((hm[l0 + jj] & m) ? 0 : 4));
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + l0) = v;
#else
    GGML_UNUSED(vx);
    GGML_UNUSED(yy);
    GGML_UNUSED(i);
    GGML_UNUSED(item_ct1);
    GGML_UNUSED(n_blocks);
    GGML_ABORT("Q3_K reorder dequantize not supported for QK_K != 256");
#endif
}

#if QK_K == 256
static inline void get_scale_min_k4(int j, const uint8_t * q, uint8_t & d, uint8_t & m) {
    if (j < 4) {
        d = q[j] & 63;
        m = q[j + 4] & 63;
    } else {
        d = (q[j+4] & 0xF) | ((q[j-4] >> 6) << 4);
        m = (q[j+4] >>  4) | ((q[j-0] >> 6) << 4);
    }
}
#endif

// Work-items that cover one 256-weight K-quant block: four 64-element chunks, 8 work-items
// per chunk, 4 qs bytes per work-item.
static constexpr int SYCL_DEQK_WI_PER_BLOCK = 32;

template <typename dst_t>
static inline void dequantize_q4_K_wide_one(dst_t * __restrict__ y, const uint8_t * __restrict__ qs,
                                            const uint8_t * __restrict__ scales, const float dall,
                                            const float dmin, const int tid) {
    const int il = tid >> 3;        // 64-element chunk, 0..3
    const int ir = (tid & 7) * 4;   // 4 qs bytes within the chunk

    uint8_t sc, m;
    get_scale_min_k4(2 * il + 0, scales, sc, m);
    const float d1 = dall * sc;
    const float m1 = dmin * m;
    get_scale_min_k4(2 * il + 1, scales, sc, m);
    const float d2 = dall * sc;
    const float m2 = dmin * m;

    const sycl::vec<uint8_t, 4> q = vec_aligned_load<uint8_t, 4>(qs + 32 * il + ir);

    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int l = 0; l < 4; ++l) {
        lo[l] = d1 * (q[l] & 0xF) - m1;
        hi[l] = d2 * (q[l] >> 4)  - m2;
    }
    dst_t * yb = y + 64 * il + ir;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb +  0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb + 32) = hi;
}

template <typename dst_t>
static void dequantize_block_q4_K_wide(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t nb,
                                       const sycl::nd_item<1> & it) {
    static_assert(QK_K == 256, "wide K-quant dequant assumes QK_K == 256");
    const int64_t g   = it.get_global_id(0);
    const int64_t b   = g / SYCL_DEQK_WI_PER_BLOCK;
    const int     tid = (int) (g % SYCL_DEQK_WI_PER_BLOCK);
    if (b >= nb) {
        return;
    }
    const block_q4_K * x = (const block_q4_K *) vx + b;
    dequantize_q4_K_wide_one(yy + b * QK_K, x->qs, x->scales, (float) x->dm[0], (float) x->dm[1], tid);
}


template <typename dst_t>
inline void dequantize_q4_K_common(dst_t * __restrict__ y, const uint8_t * __restrict__ qs_ptr, const float dall,
                                   const float dmin, uint8_t * __restrict__ scales_local, int il, int ir) {
    const int is = 2 * il;
    constexpr int n  = 4;

    uint8_t sc, m;
    get_scale_min_k4(is + 0, scales_local, sc, m);
    const float d1 = dall * sc;
    const float m1 = dmin * m;

    get_scale_min_k4(is + 1, scales_local, sc, m);
    const float d2 = dall * sc;
    const float m2 = dmin * m;

    sycl::vec<uint8_t, n> q_vec = vec_aligned_load<uint8_t, n>(qs_ptr + 32 * il + n * ir);

    sycl::vec<dst_t, n> lo, hi;
    for (int l = 0; l < n; ++l) {
        lo[l] = d1 * (q_vec[l] & 0xF) - m1;
        hi[l] = d2 * (q_vec[l] >> 4) - m2;
    }
    *reinterpret_cast<sycl::vec<dst_t, n> *>(y +  0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, n> *>(y + 32) = hi;
}

template <typename dst_t>
static void dequantize_block_q4_K_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t i,
                                          uint8_t * scales_local, const sycl::nd_item<1> & item_ct1, int64_t nb) {
    const int64_t tid = item_ct1.get_local_id(0);  // thread index within block
    const int64_t il  = tid / 8;
    const int64_t ir  = tid % 8;

    dst_t * y = yy + 64 * il + 4 * ir;

    const uint8_t * base          = static_cast<const uint8_t *>(vx);
    const size_t    qs_offset     = i * (QK_K / 2);
    const size_t    scales_offset = nb * (QK_K / 2) + i * K_SCALE_SIZE;
    const size_t    dm_offset     = nb * (QK_K / 2) + nb * K_SCALE_SIZE + i * sizeof(ggml_half2);

    const uint8_t *    qs_ptr     = base + qs_offset;
    const uint8_t *    scales_ptr = base + scales_offset;
    ggml_half2         dm_values  = *reinterpret_cast<const ggml_half2 *>(base + dm_offset);

    const float dall = dm_values.x();
    const float dmin = dm_values.y();

    if (tid < 12) {
        scales_local[tid] = scales_ptr[tid];
    }

    item_ct1.barrier(sycl::access::fence_space::local_space);
    dequantize_q4_K_common(y, qs_ptr, dall, dmin, scales_local, il, ir);
}

template <typename dst_t>
static inline void dequantize_q5_K_wide_one(dst_t * __restrict__ y, const uint8_t * __restrict__ qs,
                                            const uint8_t * __restrict__ qh_ptr,
                                            const uint8_t * __restrict__ scales, const float dall,
                                            const float dmin, const int tid) {
    const int il = tid >> 3;        // 64-element chunk, 0..3
    const int ir = (tid & 7) * 4;   // 4 qs bytes within the chunk; qh holds the 5th bit

    uint8_t sc, m;
    get_scale_min_k4(2 * il + 0, scales, sc, m);
    const float d1 = dall * sc;
    const float m1 = dmin * m;
    get_scale_min_k4(2 * il + 1, scales, sc, m);
    const float d2 = dall * sc;
    const float m2 = dmin * m;

    const sycl::vec<uint8_t, 4> q = vec_aligned_load<uint8_t, 4>(qs + 32 * il + ir);
    const sycl::vec<uint8_t, 4> h = vec_aligned_load<uint8_t, 4>(qh_ptr + ir);

    const uint8_t hm1 = 1 << (2 * il);
    const uint8_t hm2 = hm1 << 1;

    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int l = 0; l < 4; ++l) {
        lo[l] = d1 * ((q[l] & 0xF) + ((h[l] & hm1) ? 16 : 0)) - m1;
        hi[l] = d2 * ((q[l] >>  4) + ((h[l] & hm2) ? 16 : 0)) - m2;
    }
    dst_t * yb = y + 64 * il + ir;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb +  0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yb + 32) = hi;
}

template <typename dst_t>
static void dequantize_block_q5_K_wide(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t nb,
                                       const sycl::nd_item<1> & it) {
    static_assert(QK_K == 256, "wide K-quant dequant assumes QK_K == 256");
    const int64_t g   = it.get_global_id(0);
    const int64_t b   = g / SYCL_DEQK_WI_PER_BLOCK;
    const int     tid = (int) (g % SYCL_DEQK_WI_PER_BLOCK);
    if (b >= nb) {
        return;
    }
    const block_q5_K * x = (const block_q5_K *) vx + b;
    dequantize_q5_K_wide_one(yy + b * QK_K, x->qs, x->qh, x->scales, (float) x->dm[0], (float) x->dm[1], tid);
}

template <typename dst_t>
static void dequantize_block_q5_K_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t ib,
                                          uint8_t * scales_local, const sycl::nd_item<3> & item_ct1, int64_t n_blocks) {

#if QK_K == 256
    // remapped decomposition: 32 threads, each emitting two aligned vec<dst_t,4>
    // from four consecutive ql/qh bytes; a 4-element run shares one scale pair,
    // so the per-element math and output are identical to the 64-thread kernel.
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t il  = tid / 8;   // 0...3
    const int64_t ir  = tid % 8;   // 0...7
    const int64_t is  = 2 * il;

    dst_t * y = yy + 64 * il + 4 * ir;

    const uint8_t * base = static_cast<const uint8_t *>(vx);

    // Reordered layout: [qs (QK_K/2 per block)] [qh (QK_K/8 per block)] [scales (K_SCALE_SIZE per block)] [dm (half2 per block)]
    const size_t qs_offset     = ib * (QK_K / 2);
    const size_t qh_offset     = n_blocks * (QK_K / 2) + ib * (QK_K / 8);
    const size_t scales_offset = n_blocks * (QK_K / 2) + n_blocks * (QK_K / 8) + ib * K_SCALE_SIZE;
    const size_t dm_offset     = n_blocks * (QK_K / 2) + n_blocks * (QK_K / 8) + n_blocks * K_SCALE_SIZE + ib * sizeof(ggml_half2);

    const uint8_t *  qs_ptr     = base + qs_offset;
    const uint8_t *  qh_ptr     = base + qh_offset;
    const uint8_t *  scales_ptr = base + scales_offset;
    const ggml_half2 dm_values  = *reinterpret_cast<const ggml_half2 *>(base + dm_offset);

    const float dall = dm_values.x();
    const float dmin = dm_values.y();

    const uint8_t * ql = qs_ptr + 32 * il + 4 * ir;   // four consecutive bytes
    const uint8_t * qh = qh_ptr + 4 * ir;             // four consecutive bytes

    if (tid < K_SCALE_SIZE) {
        scales_local[tid] = scales_ptr[tid];
    }

    item_ct1.barrier(sycl::access::fence_space::local_space);

    uint8_t sc, m;
    get_scale_min_k4(is + 0, scales_local, sc, m);
    const float d1 = dall * sc; const float m1 = dmin * m;
    get_scale_min_k4(is + 1, scales_local, sc, m);
    const float d2 = dall * sc; const float m2 = dmin * m;

    const uint8_t hm_lo = 1 << (2 * il);
    const uint8_t hm_hi = 1 << (2 * il + 1);

    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        lo[j] = d1 * ((ql[j] & 0xF) + (qh[j] & hm_lo ? 16 : 0)) - m1;
        hi[j] = d2 * ((ql[j] >>  4) + (qh[j] & hm_hi ? 16 : 0)) - m2;
    }

    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y +  0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + 32) = hi;
#else
    GGML_UNUSED(ib); GGML_UNUSED(tid); GGML_UNUSED(yy); GGML_UNUSED(scales_local); GGML_UNUSED(n_blocks);
    GGML_ABORT("Q5_K reorder dequantize not supported for QK_K != 256");
#endif
}

template<typename dst_t>
static void dequantize_block_q6_K(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                  const sycl::nd_item<3> &item_ct1) {
    const block_q6_K * x = (const block_q6_K *) vx;

    const int64_t i = item_ct1.get_group(2);
#if QK_K == 256

    // assume 64 threads - this is very slightly better than the one below
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t ip  = tid/32;   // ip is 0 or 1
    const int64_t il  = tid - 32*ip; // 0...32
    const int64_t is  = 8*ip + il/16;

    dst_t * y = yy + i*QK_K + 128*ip + il;

    const float d = x[i].d;

    const uint8_t * ql = x[i].ql + 64*ip + il;
    const uint8_t   qh = x[i].qh[32*ip + il];
    const int8_t  * sc = x[i].scales + is;

    y[ 0] = d * sc[0] * ((int8_t)((ql[ 0] & 0xF) | (((qh >> 0) & 3) << 4)) - 32);
    y[32] = d * sc[2] * ((int8_t)((ql[32] & 0xF) | (((qh >> 2) & 3) << 4)) - 32);
    y[64] = d * sc[4] * ((int8_t)((ql[ 0]  >> 4) | (((qh >> 4) & 3) << 4)) - 32);
    y[96] = d * sc[6] * ((int8_t)((ql[32]  >> 4) | (((qh >> 6) & 3) << 4)) - 32);
#else

    // assume 32 threads
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t ip  = tid/16;         // 0 or 1
    const int64_t il  = tid - 16*ip;    // 0...15

    dst_t * y = yy + i*QK_K + 16*ip + il;

    const float d = x[i].d;

    const uint8_t   ql = x[i].ql[16*ip + il];
    const uint8_t   qh = x[i].qh[il] >> (2*ip);
    const int8_t  * sc = x[i].scales;

    y[ 0] = d * sc[ip+0] * ((int8_t)((ql & 0xF) | (((qh >> 0) & 3) << 4)) - 32);
    y[32] = d * sc[ip+2] * ((int8_t)((ql  >> 4) | (((qh >> 4) & 3) << 4)) - 32);
#endif
}

template <typename dst_t>
static void dequantize_block_q6_K_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t ib,
                                          const sycl::nd_item<3> & item_ct1, int64_t n_blocks) {
    // remapped decomposition: each of the 64 threads emits one aligned vec<dst_t,4>
    // instead of four scalars strided 32 apart. The four elements of a run share one
    // 16-element scale group, one ql nibble source and one qh bit pair, so the
    // per-element math and the output are identical to the scalar kernel.
    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t ip  = tid / 32;             // 128-element half: 0 or 1
    const int64_t eh0 = 4 * (tid - 32 * ip);  // base element within the half

    const uint8_t *   base_ptr           = static_cast<const uint8_t *>(vx);
    const auto        ql_offset          = ib * (QK_K / 2);
    const auto        qh_offset          = (QK_K / 2) * n_blocks + (QK_K / 4) * ib;
    const auto        base_scales_offset = (QK_K / 2) * n_blocks + (QK_K / 4) * n_blocks + (QK_K / 16) * ib;
    const auto        base_d_offset      = ((QK_K / 2) + (QK_K / 4) + (QK_K / 16)) * n_blocks;
    const uint8_t *   ql_ptr             = base_ptr + ql_offset;
    const uint8_t *   qh_ptr             = base_ptr + qh_offset;
    const uint8_t *   scales_ptr         = base_ptr + base_scales_offset;
    const ggml_half * d                  = (const ggml_half *) (base_ptr + base_d_offset) + ib;

    const int        shift = eh0 >= 64 ? 4 : 0;      // low or high ql nibble
    const int        qb    = 2 * (eh0 / 32);         // qh bit pair: 0/2/4/6
    const int8_t     sc0   = reinterpret_cast<const int8_t *>(scales_ptr + 8 * ip + eh0 / 16)[0];
    const uint8_t *  ql4   = ql_ptr + 64 * ip + (eh0 & 63);
    const uint8_t *  qh4   = qh_ptr + 32 * ip + (eh0 & 31);

    sycl::vec<dst_t, 4> v;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        v[j] = *d * sc0 * ((int8_t) (((ql4[j] >> shift) & 0xF) | ((((qh4[j] >> qb) & 3)) << 4)) - 32);
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(yy + 128 * ip + eh0) = v;
}

template<typename dst_t>
static void dequantize_block_iq2_xxs(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                     const sycl::nd_item<3> &item_ct1,
                                     const uint64_t *iq2xxs_grid_ptr,
                                     const uint8_t *ksigns_iq2xs_ptr,
                                     const uint8_t *kmask_iq2xs_ptr) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq2_xxs * x = (const block_iq2_xxs  *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint16_t * q2 = x[i].qs + 4*ib;
    const uint8_t  * aux8 = (const uint8_t *)q2;
    const uint8_t  * grid = (const uint8_t *)(iq2xxs_grid_ptr + aux8[il]);
    const uint32_t aux32 = q2[2] | (q2[3] << 16);
    const float d = (float)x[i].d * (0.5f + (aux32 >> 28)) * 0.25f;
    const uint8_t signs = ksigns_iq2xs_ptr[(aux32 >> 7*il) & 127];
    for (int j = 0; j < 8; ++j) y[j] = d * grid[j] * (signs & kmask_iq2xs_ptr[j] ? -1.f : 1.f);
#else
    assert(false);
#endif

}

template<typename dst_t>
static void dequantize_block_iq2_xs(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                    const sycl::nd_item<3> &item_ct1,
                                    const uint64_t *iq2xs_grid,
                                    const uint8_t *ksigns_iq2xs,
                                    const uint8_t *kmask_iq2xs) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq2_xs * x = (const block_iq2_xs *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint16_t * q2 = x[i].qs + 4*ib;
    const uint8_t  * grid = (const uint8_t *)(iq2xs_grid + (q2[il] & 511));
    const float d = (float)x[i].d * (0.5f + ((x[i].scales[ib] >> 4*(il/2)) & 0xf)) * 0.25f;
    const uint8_t signs = ksigns_iq2xs[q2[il] >> 9];
    for (int j = 0; j < 8; ++j) y[j] = d * grid[j] * (signs & kmask_iq2xs[j] ? -1.f : 1.f);
#else
    assert(false);
#endif

}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq2_s(const void *__restrict__ vx, dst_t *__restrict__ yy,
                       const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq2_s * x = (const block_iq2_s *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint8_t * grid = (const uint8_t *)(iq2s_grid + (x[i].qs[4*ib+il] | ((x[i].qh[ib] << (8-2*il)) & 0x300)));
    const float d = (float)x[i].d * (0.5f + ((x[i].scales[ib] >> 4*(il/2)) & 0xf)) * 0.25f;
    const uint8_t signs = x[i].qs[QK_K/8+4*ib+il];
#pragma unroll
    for (int j = 0; j < 8; ++j)
        y[j] = d * grid[j] * (signs & kmask_iq2xs[j] ? -1.f : 1.f);
#else
    assert(false);

#endif

}

template<typename dst_t>
static void dequantize_block_iq3_xxs(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                     const sycl::nd_item<3> &item_ct1,
                                     const uint32_t *iq3xxs_grid,
                                     const uint8_t *ksigns_iq2xs,
                                     const uint8_t *kmask_iq2xs) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq3_xxs * x = (const block_iq3_xxs  *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint8_t  * q3 = x[i].qs + 8*ib;
    const uint16_t * gas = (const uint16_t *)(x[i].qs + QK_K/4) + 2*ib;
    const uint8_t  * grid1 = (const uint8_t *)(iq3xxs_grid + q3[2*il+0]);
    const uint8_t  * grid2 = (const uint8_t *)(iq3xxs_grid + q3[2*il+1]);
    const uint32_t aux32 = gas[0] | (gas[1] << 16);
    const float d = (float)x[i].d * (0.5f + (aux32 >> 28)) * 0.5f;
    const uint8_t signs = ksigns_iq2xs[(aux32 >> 7*il) & 127];
    for (int j = 0; j < 4; ++j) {
        y[j+0] = d * grid1[j] * (signs & kmask_iq2xs[j+0] ? -1.f : 1.f);
        y[j+4] = d * grid2[j] * (signs & kmask_iq2xs[j+4] ? -1.f : 1.f);
    }
#else
    assert(false);
#endif

}

template<typename dst_t>
static void dequantize_block_iq3_xxs_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t i,
                                             const sycl::nd_item<3> & item_ct1, const int64_t nb,
                                             const uint32_t * iq3xxs_grid,
                                             const uint8_t * ksigns_iq2xs,
                                             const uint8_t * kmask_iq2xs) {
    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid / 8;
    const int64_t ib = tid % 8;
    const uint8_t * base = static_cast<const uint8_t *>(vx);
    const uint8_t * qs = base + i * (3 * QK_K / 8);
    const ggml_half * d = reinterpret_cast<const ggml_half *>(base + nb * (3 * QK_K / 8));
    const uint8_t * q3 = qs + 8 * ib;
    const uint16_t * gas = reinterpret_cast<const uint16_t *>(qs + QK_K / 4) + 2 * ib;
    const uint8_t * grid1 = reinterpret_cast<const uint8_t *>(iq3xxs_grid + q3[2*il+0]);
    const uint8_t * grid2 = reinterpret_cast<const uint8_t *>(iq3xxs_grid + q3[2*il+1]);
    const uint32_t aux32 = gas[0] | (gas[1] << 16);
    const float dl = (float) d[i] * (0.5f + (aux32 >> 28)) * 0.5f;
    const uint8_t signs = ksigns_iq2xs[(aux32 >> (7 * il)) & 127];
    dst_t * y = yy + 32 * ib + 8 * il;
    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        lo[j] = dl * grid1[j] * (signs & kmask_iq2xs[j+0] ? -1.f : 1.f);
        hi[j] = dl * grid2[j] * (signs & kmask_iq2xs[j+4] ? -1.f : 1.f);
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + 0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + 4) = hi;
#else
    GGML_UNUSED(vx);
    GGML_UNUSED(yy);
    GGML_UNUSED(i);
    GGML_UNUSED(item_ct1);
    GGML_UNUSED(nb);
    GGML_UNUSED(iq3xxs_grid);
    GGML_UNUSED(ksigns_iq2xs);
    GGML_UNUSED(kmask_iq2xs);
    GGML_ABORT("IQ3_XXS reorder dequantization requires QK_K == 256");
#endif
}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq3_s(const void *__restrict__ vx, dst_t *__restrict__ yy,
                       const sycl::nd_item<3> &item_ct1,
                       const uint8_t *kmask_iq2xs, const uint32_t *iq3s_grid) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq3_s * x = (const block_iq3_s *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint8_t * qs = x[i].qs + 8*ib;
    const uint8_t * grid1 = (const uint8_t *)(iq3s_grid + (qs[2*il+0] | ((x[i].qh[ib] << (8-2*il)) & 256)));
    const uint8_t * grid2 = (const uint8_t *)(iq3s_grid + (qs[2*il+1] | ((x[i].qh[ib] << (7-2*il)) & 256)));
    const float d = (float)x[i].d * (1 + 2*((x[i].scales[ib/2] >> 4*(ib%2)) & 0xf));
    const uint8_t signs = x[i].signs[4*ib + il];
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        y[j+0] = d * grid1[j] * (signs & kmask_iq2xs[j+0] ? -1.f : 1.f);
        y[j+4] = d * grid2[j] * (signs & kmask_iq2xs[j+4] ? -1.f : 1.f);
    }
#else
    assert(false);
#endif

}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq3_s_reorder(const void * __restrict__ vx, dst_t * __restrict__ yy, const int64_t i,
                               const sycl::nd_item<3> & item_ct1, const int64_t nb,
                               const uint8_t * kmask_iq2xs, const uint32_t * iq3s_grid) {
    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid / 8;
    const int64_t ib = tid % 8;
    const uint8_t * base = static_cast<const uint8_t *>(vx);
    const uint8_t * qs = base + i * (QK_K / 4);
    const uint8_t * qh = base + nb * (QK_K / 4) + i * (QK_K / 32);
    const uint8_t * signs_base = base + nb * (QK_K / 4 + QK_K / 32) + i * (QK_K / 8);
    const uint8_t * metadata = base + nb * (QK_K / 4 + QK_K / 32 + QK_K / 8) +
                               i * (sizeof(ggml_half) + IQ3S_N_SCALE);
    const ggml_half d = *reinterpret_cast<const ggml_half *>(metadata);
    const uint8_t * scales = metadata + sizeof(ggml_half);
    const uint8_t * qs_ib = qs + 8 * ib;
    const uint8_t * grid1 = reinterpret_cast<const uint8_t *>(
        iq3s_grid + (qs_ib[2*il+0] | ((qh[ib] << (8 - 2*il)) & 256)));
    const uint8_t * grid2 = reinterpret_cast<const uint8_t *>(
        iq3s_grid + (qs_ib[2*il+1] | ((qh[ib] << (7 - 2*il)) & 256)));
    const float dl = (float) d * (1 + 2 * ((scales[ib/2] >> (4 * (ib%2))) & 0xf));
    const uint8_t signs = signs_base[4 * ib + il];
    dst_t * y = yy + 32 * ib + 8 * il;
    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        lo[j] = dl * grid1[j] * (signs & kmask_iq2xs[j+0] ? -1.f : 1.f);
        hi[j] = dl * grid2[j] * (signs & kmask_iq2xs[j+4] ? -1.f : 1.f);
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + 0) = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + 4) = hi;
#else
    GGML_UNUSED(vx);
    GGML_UNUSED(yy);
    GGML_UNUSED(i);
    GGML_UNUSED(item_ct1);
    GGML_UNUSED(nb);
    GGML_UNUSED(kmask_iq2xs);
    GGML_UNUSED(iq3s_grid);
    GGML_ABORT("IQ3_S reorder dequantization requires QK_K == 256");
#endif
}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq1_s(const void *__restrict__ vx, dst_t *__restrict__ yy,
                       const sycl::nd_item<3> &item_ct1,
                       const uint32_t *iq1s_grid_gpu) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq1_s * x = (const block_iq1_s  *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const float delta = x[i].qh[ib] & 0x8000 ? -1 - IQ1S_DELTA : -1 + IQ1S_DELTA;
    const float d = (float)x[i].d * (2*((x[i].qh[ib] >> 12) & 7) + 1);
    uint32_t grid32[2]; const int8_t * q = (const int8_t *)grid32;
    grid32[0] = iq1s_grid_gpu[x[i].qs[4*ib+il] | (((x[i].qh[ib] >> 3*il) & 7) << 8)];
    grid32[1] = (grid32[0] >> 4) & 0x0f0f0f0f;
    grid32[0] &= 0x0f0f0f0f;
#pragma unroll
    for (int j = 0; j < 8; ++j) {
        y[j] = d * (q[j] + delta);
    }
#else
    assert(false);
#endif

}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq1_m(const void *__restrict__ vx, dst_t *__restrict__ yy,
                       const sycl::nd_item<3> &item_ct1,
                       const uint32_t *iq1s_grid_gpu) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq1_m * x = (const block_iq1_m  *) vx;

    const int64_t tid = item_ct1.get_local_id(2);
#if QK_K == 256
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 8*il;
    const uint16_t * sc = (const uint16_t *)x[i].scales;
    iq1m_scale_t scale;
    scale.u16 = (sc[0] >> 12) | ((sc[1] >> 8) & 0x00f0) | ((sc[2] >> 4) & 0x0f00) | (sc[3] & 0xf000);
    const int ib16 = 2*ib + il/2; // sc[ib16/4] >> 3*(ib16%4) -> sc[ib/2] >> 3*((2*ib+il/2)%4);
    const float d = (float)scale.f16 * (2*((sc[ib16/4] >> 3*(ib16%4)) & 0x7) + 1);
    const float delta = x[i].qh[2*ib+il/2] & (0x08 << 4*(il%2)) ? -1 - IQ1M_DELTA : -1 + IQ1M_DELTA;
    uint32_t grid32[2]; const int8_t * q = (const int8_t *)grid32;
    grid32[0] = iq1s_grid_gpu[x[i].qs[4*ib+il] | (((x[i].qh[2*ib+il/2] >> 4*(il%2)) & 7) << 8)];
    grid32[1] = (grid32[0] >> 4) & 0x0f0f0f0f;
    grid32[0] &= 0x0f0f0f0f;
#pragma unroll
    for (int j = 0; j < 8; ++j) {
        y[j] = d * (q[j] + delta);
    }
#else
    assert(false);
#endif

}

template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq4_nl(const void *__restrict__ vx, dst_t *__restrict__ yy,
                        const sycl::nd_item<3> &item_ct1) {

    const int64_t i = item_ct1.get_group(2);
    const block_iq4_nl * x = (const block_iq4_nl *) vx + i*(QK_K/QK4_NL);

    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 4*il;
    const uint8_t  * q4 = x[ib].qs + 4*il;
    const float d = (float)x[ib].d;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        y[j+ 0] = d * kvalues_iq4nl[q4[j] & 0xf];
        y[j+16] = d * kvalues_iq4nl[q4[j] >>  4];
    }

}


template <typename dst_t>
__dpct_inline__ static void
dequantize_block_iq4_xs(const void *__restrict__ vx, dst_t *__restrict__ yy,
                        const sycl::nd_item<3> &item_ct1) {
    const int64_t i = item_ct1.get_group(2);
    const block_iq4_xs * x = (const block_iq4_xs *)vx;

    const int64_t tid = item_ct1.get_local_id(2);
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 4*il;
    const uint8_t  * q4 = x[i].qs + 16*ib + 4*il;
    const float d = (float)x[i].d * ((((x[i].scales_l[ib/2] >> 4*(ib%2)) & 0xf) | (((x[i].scales_h >> 2*ib) & 3) << 4)) - 32);
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        y[j+ 0] = d * kvalues_iq4nl[q4[j] & 0xf];
        y[j+16] = d * kvalues_iq4nl[q4[j] >>  4];
    }
}

template<typename dst_t>
static void dequantize_block_mxfp4(const void * __restrict__ vx, dst_t * __restrict__ yy,
                                   const sycl::nd_item<3> &item_ct1) {
    // auto                item_ct1 = sycl::ext::oneapi::this_work_item::get_nd_item<3>();
    const int64_t       i        = item_ct1.get_group(2);
    const block_mxfp4 * x = (const block_mxfp4 *) vx + i*(QK_K/QK_MXFP4);

    const int64_t    tid = item_ct1.get_local_id(2);
    const int64_t il = tid/8; // 0...3
    const int64_t ib = tid%8; // 0...7
    dst_t * y = yy + i*QK_K + 32*ib + 4*il;
    const uint8_t  * q4 = x[ib].qs + 4*il;
    const float d = ggml_sycl_e8m0_to_fp32(x[ib].e);
    for (int j = 0; j < 4; ++j) {
        y[j+ 0] = d * kvalues_mxfp4[q4[j] & 0xf]*0.5f;
        y[j+16] = d * kvalues_mxfp4[q4[j] >>  4]*0.5f;
    }
}

// Reordered MXFP4 ([qs...][e...], see ggml_sycl_reordered::block_q_t<MXFP4>).
// four qs bytes per item, all inside one 32-element block: two vec<dst_t,4> stores.
// same LUT lookups and per-block scale; bit-identical output.
template<typename dst_t>
static void dequantize_block_mxfp4_reorder_wide(const void * __restrict__ vx, dst_t * __restrict__ yy, int64_t k,
                                                const sycl::id<1> idx) {
    const int64_t i  = (int64_t) idx[0];
    const int64_t ib = i / 4;
    const int64_t iq = 4 * (i % 4);   // first of four qs bytes in the block

    const uint8_t * qs = (const uint8_t *) vx + ib * (QK_MXFP4 / 2);
    const float     d  = ggml_sycl_e8m0_to_fp32(((const uint8_t *) vx)[k / 2 + ib]) * 0.5f;
    dst_t *         y  = yy + ib * QK_MXFP4 + iq;

    sycl::vec<dst_t, 4> lo, hi;
#pragma unroll
    for (int j = 0; j < 4; ++j) {
        lo[j] = d * kvalues_mxfp4[qs[iq + j] & 0xf];
        hi[j] = d * kvalues_mxfp4[qs[iq + j] >> 4];
    }
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y)                = lo;
    *reinterpret_cast<sycl::vec<dst_t, 4> *>(y + QK_MXFP4 / 2) = hi;
}


template <typename dst_t>
static void dequantize_block_nvfp4(
        const void * __restrict__ vx,
        dst_t * __restrict__ yy,
        const int64_t ne) {
    auto          item_ct1 = sycl::ext::oneapi::this_work_item::get_nd_item<3>();
    const int64_t i        = item_ct1.get_group(2);
    const int     tid      = item_ct1.get_local_id(2);

    const int64_t base = i * QK_NVFP4;
    if (base >= ne) {
        return;
    }

    const block_nvfp4 * x = (const block_nvfp4 *) vx;
    const block_nvfp4 & xb = x[i];

    const int sub = tid / (QK_NVFP4_SUB / 2);
    const int j = tid % (QK_NVFP4_SUB / 2);

    const float d = ggml_sycl_ue4m3_to_fp32(xb.d[sub]);
    const uint8_t q = xb.qs[sub * (QK_NVFP4_SUB / 2) + j];

    const int64_t y0 = base + sub * QK_NVFP4_SUB + j;
    const int64_t y1 = y0 + QK_NVFP4_SUB / 2;

    yy[y0] = ggml_sycl_cast<dst_t>(d * kvalues_mxfp4[q & 0x0F]);
    yy[y1] = ggml_sycl_cast<dst_t>(d * kvalues_mxfp4[q >> 4]);
}


#endif // GGML_SYCL_DEQUANTIZE_HPP
