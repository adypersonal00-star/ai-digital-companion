#include <jni.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include "stable-diffusion.h"
extern "C" JNIEXPORT jbyteArray JNICALL
Java_ai_ady_companion_ImageGeneratorNative_generate(JNIEnv* env, jclass, jstring model_, jstring prompt_, jint width, jint height, jint steps, jlong seed) {
    if (!model_ || !prompt_) return nullptr;
    const char* model = env->GetStringUTFChars(model_, nullptr);
    const char* prompt = env->GetStringUTFChars(prompt_, nullptr);
    if (!model || !prompt) { if(model) env->ReleaseStringUTFChars(model_,model); if(prompt) env->ReleaseStringUTFChars(prompt_,prompt); return nullptr; }
    sd_ctx_params_t cp; sd_ctx_params_init(&cp); cp.model_path=model; cp.n_threads=2; cp.enable_mmap=true; cp.rng_type=CPU_RNG; cp.sampler_rng_type=CPU_RNG;
    sd_ctx_t* ctx = new_sd_ctx(&cp);
    jbyteArray output = nullptr;
    if(ctx) {
      sd_img_gen_params_t gp; sd_img_gen_params_init(&gp); gp.prompt=prompt; gp.width=width; gp.height=height; gp.seed=(int64_t)seed; gp.batch_count=1;
      sd_sample_params_init(&gp.sample_params); gp.sample_params.sample_steps=steps; gp.sample_params.sample_method=sd_get_default_sample_method(ctx); gp.sample_params.scheduler=sd_get_default_scheduler(ctx,gp.sample_params.sample_method); gp.sample_params.guidance.txt_cfg=7.0f;
      sd_image_generation_result_t* result=nullptr;
      if(generate_image(ctx,&gp,&result) && result && result->count>0 && result->items[0].image.data) {
        sd_image_t im=result->items[0].image; const size_t pixels=(size_t)im.width*im.height; const size_t n=pixels*3;
        if(im.channel>=3 && n<64u*1024u*1024u) { std::vector<jbyte> bytes(8+n); uint32_t w=im.width,h=im.height; memcpy(bytes.data(),&w,4);memcpy(bytes.data()+4,&h,4);for(size_t i=0;i<pixels;i++){bytes[8+i*3]=im.data[i*im.channel];bytes[9+i*3]=im.data[i*im.channel+1];bytes[10+i*3]=im.data[i*im.channel+2];}output=env->NewByteArray((jsize)bytes.size());if(output)env->SetByteArrayRegion(output,0,(jsize)bytes.size(),bytes.data()); }
      }
      if(result)free_sd_image_generation_result(result);
      free_sd_ctx(ctx);
    }
    env->ReleaseStringUTFChars(model_,model); env->ReleaseStringUTFChars(prompt_,prompt); return output;
}
